<?php if(session('successMessage')): ?>
    <div <?php echo e($attributes->merge(['class' => 'flex justify-center'])); ?>>
        <div class="min-w-[100px] bg-green-500 text-white rounded px-4 py-2 shadow">
            <?php echo e(session('successMessage')); ?>

        </div>
    </div>
<?php endif; ?><?php /**PATH E:\Majdza\todo\resources\views/components/success-message.blade.php ENDPATH**/ ?>