<div class="mb-3">
    <label
        for="body"
        class="form-label inline-block mb-2 text-gray-700"
    >Opis</label>
    <textarea
        class="
          form-control
          block
          w-full
          px-3
          py-1.5
          text-base
          font-normal
          text-gray-700
          bg-white bg-clip-padding
          border border-solid border-gray-300
          rounded
          transition
          ease-in-out
          m-0
          focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none
        "
        id="body"
        rows="3"
        placeholder="Unesi opis zadatka"
        name="body"
        required
    ><?php echo e(old('body') ?? $model->body); ?></textarea>

    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH E:\Majdza\todo\resources\views/includes/_body.blade.php ENDPATH**/ ?>