<?php foreach($attributes->onlyProps(['color' => 'blue', 'small' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['color' => 'blue', 'small' => false]); ?>
<?php foreach (array_filter((['color' => 'blue', 'small' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $colorClasses = match($color) {
        'red' => 'bg-red-600 hover:bg-red-700 focus:bg-red-700 active:bg-red-800',
        'gray' => 'bg-gray-600 hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-800',
        'blue' => 'bg-blue-600 hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-800',
        default => 'bg-blue-600 hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-800',
    }
?>

<button class="inline-block <?php echo e($small ? 'px-2 py-1' : 'px-6 py-2.5'); ?> <?php echo e($colorClasses); ?> text-white  text-xs leading-tight uppercase rounded shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0  active:shadow-lg transition duration-150 ease-in-out">
    <?php echo e($slot); ?>

</button>

<?php /**PATH E:\Majdza\todo\resources\views/components/button.blade.php ENDPATH**/ ?>