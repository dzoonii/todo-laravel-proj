<?php foreach($attributes->onlyProps(['title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title']); ?>
<?php foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="block p-6 rounded-lg shadow-lg bg-white">
    <h5 class="text-gray-900 text-xl leading-tight font-medium mb-2">
        <?php echo e($title); ?>

    </h5>

    <div class="text-gray-700 text-base mt-4">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH E:\Majdza\todo\resources\views/components/card.blade.php ENDPATH**/ ?>